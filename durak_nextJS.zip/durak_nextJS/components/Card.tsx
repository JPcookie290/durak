import { Card as CardType } from "../types"; // Assuming you define this

interface Props {
  card: CardType;
}

export default function Card({ card }: Props) {
  return (
    <div className="card">
      <img src={card.image} alt={`${card.value} of ${card.suit}`} />
    </div>
  );
}
