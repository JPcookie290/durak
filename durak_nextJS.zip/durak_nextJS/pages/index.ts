import Hand from "../components/Hand";
import CardDeck from "../components/CardDeck";
import { Card } from "../types"; // Assuming you have defined this type

export default function Home() {
  const dummyCards: Card[] = [
    { code: "6H", image: "/images/6H.png", suit: "hearts", value: "6" },
    { code: "7H", image: "/images/7H.png", suit: "hearts", value: "7" },
    { code: "8H", image: "/images/8H.png", suit: "hearts", value: "8" },
  ];

  return (
    <div className={styles.container}>
      <main className={styles.main}>
        <h1 className={styles.title}>Welcome to Durak Game</h1>
        <CardDeck />
        <Hand cards={dummyCards} isPlayer={true} />
        <Hand cards={dummyCards} isPlayer={false} />
      </main>
    </div>
  );
}
