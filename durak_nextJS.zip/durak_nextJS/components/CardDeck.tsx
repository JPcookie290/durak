import { ICard as CardType } from "../utils/index";

export default function CardDeck() {
  return (
    <div className="deck">
      <p>Deck of cards</p>
    </div>
  );
}

CardDeck;
