export interface Card {
  suit: string;
  value: string;
}
